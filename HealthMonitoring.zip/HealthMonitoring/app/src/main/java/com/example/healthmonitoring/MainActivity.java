package com.example.healthmonitoring;

import android.Manifest;
import android.arch.lifecycle.ViewModelStoreOwner;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


   // private Button btn_send_to_server;
    private EditText fname,lname,pulse_rate,temp,bp,respiration, text_location;
    private int REQUEST_CODE = 1;
    //btn_send_to_server.OnClickListener(this)


    double longitude = 0, latitude = 0;
    Location location;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fname = findViewById(R.id.first_name);
        lname = findViewById(R.id.last_name);

        pulse_rate = findViewById(R.id.txt_pulse_rate);
        temp = findViewById(R.id.txt_temperature);
        bp = findViewById(R.id.txt_bp);
        respiration = findViewById(R.id.txt_respiration);

        text_location = findViewById(R.id.txt_location);

        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }

        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        longitude = location.getLongitude();
        latitude = location.getLatitude();
        Button btn_send_to_server= findViewById(R.id.btn_send_to_server);
        btn_send_to_server.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));

                Toast toast=Toast.makeText(getApplicationContext(),"Sending Data.."  +  getLocation(),Toast.LENGTH_SHORT);
               // toast.setMargin(50,50);
                toast.show();

                text_location.setText(getLocation2Digits());
            }
        });


        Button btn_about = findViewById(R.id.btn_about);
        btn_about.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));

                Toast toast=Toast.makeText(getApplicationContext(),"ABOUT",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();

                text_location.setText(getLocation2Digits());
            }
        });

        Button btn_connect = findViewById(R.id.btn_connect);
        btn_connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));

                Toast toast=Toast.makeText(getApplicationContext(),"Connect",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();

                text_location.setText(getLocation2Digits());
            }
        });


        Button btn_generate_data = findViewById(R.id.btn_generate_data);
        btn_generate_data.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));

                Toast toast=Toast.makeText(getApplicationContext(),"Generating Data...",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();

                text_location.setText(getLocation2Digits());


            }
        });
    }

    public String getLocation() {
        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        longitude = location.getLongitude();
        latitude = location.getLatitude();
            return ("" + longitude + "/" + latitude);

    }

    public String getLocation2Digits() {
        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }




        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        longitude = location.getLongitude();
        latitude = location.getLatitude();
        return ("" + String.format("%.5f",longitude) + "/" + String.format("%.5f",latitude));

    }


    @Override
    public void onClick(View v) {

        //Your Logic
    }



    public void visitPage(){

    }



}
